<?php

use yii\helpers\Html;
use common\models\PermintaanBarang;
use yii\helpers\Url;
$permintaan = PermintaanBarang::find()->where(['<','status',4])->count();

/* @var $this yii\web\View */
/* @var $model common\models\PermintaanBarang */

$this->title = 'Create Permintaan Barang';
$this->params['breadcrumbs'][] = ['label' => 'Permintaan Barangs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class='box box-body'>
    <h1><?= Html::encode($this->title) ?></h1>
	<hr>
<?php if($permintaan > 0){ ?>
<div class="alert alert-danger" role="alert">
	<h6>Tidak bisa membuat pengajuan karena pengajuan sebelumnya belum selesai di proses , silahkan edit pengajuan sebelumnya untuk menambah atau mengubah barang </h6>
</div>
<a  href='<?= Url::to(['/permintaan-barang']) ?>' class='btn btn-warning'>Kembali</a>
<?php }else{ ?>
<div class="permintaan-barang-create">



    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
<?php } ?>
</div>
