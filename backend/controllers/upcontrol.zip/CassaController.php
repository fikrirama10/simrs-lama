<?php

namespace backend\controllers;

use Yii;
use common\models\Rawatjalan;
use common\models\Trandetail;
use common\models\Transaksi;
use common\models\TransaksiSearch;
use common\models\Keluhan;
use common\models\Resepdokter;
use common\models\Tindakandokter;
use common\models\RawatjalanSearch;
use yii\web\Controller;
use yii\base\Model;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * RawatjalanController implements the CRUD actions for Rawatjalan model.
 */
class CassaController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Rawatjalan models.
     * @return mixed
     */
  public function actionIndex()
    {
		

        $searchModel = new RawatjalanSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        // get your HTML raw content without any layouts or scripts
		
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
			
			
        ]);
    }
	public function actionDatabayar()
    {		
		$where = ['status'=>1];
        $searchModel = new TransaksiSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $where);
      
		
        return $this->render('databayar', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
			
        ]);
    }
	 public function actionGetSearch($start='', $end='',$cek='',$search='',$search2='')
    {
		if($start !== '' && $end !== '' && $cek !== ''){
			if($cek == 'today'){ $title = 'Hari ini'; }
			else if($cek == 'this_month'){ $title = 'Bulan ini'; }
			else if($cek == 'this_year'){ $title = 'Tahun ini'; }
			else if($cek == 'custom'){ $title = 'Periode'; }
			
			// else if($cek == 'custom'){ $title = 'Periode '.date('d F Y', strtotime($start)).' - '.date('d F Y', strtotime($end)); }
			$start = date('Y-m-d', strtotime($start));
			$end = date('Y-m-d', strtotime($end));
			$where = ['between', 'DATE_FORMAT(tgldaftar,"%Y-%m-%d")', $start, $end];
			//$andWhere = ['or',['like', 'pasien.nama_pasien', $search2], ];
			$andFilterWhere = ['or',['like', 'idjenisrawat', $search], ];
		}else{
			$where = ['between', 'DATE_FORMAT(tgldaftar,"%Y-%m-%d")', date('Y-m-d'), date('Y-m-d')];
			//$andWhere = ['IdStat'=>4];
			//$andWhere = ['or',['like', 'pasien.nama_pasien', $search2], ];
			$andFilterWhere = ['or',['like', 'idjenisrawat', $search], ];
		
		
		}

        $searchModel = new RawatjalanSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $where,$andFilterWhere);
     

        return $this->renderAjax('search', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
			
			'title'=>$title,
			
		
        ]);
    }

    /**
     * Displays a single Rawatjalan model.
     * @param integer $id
     * @return mixed
     */
	public function actionEdit($id)
    {
		$trx = new Trandetail;
		$tra = $this->findTindakan($id);
		$model = Rawatjalan::find()->where(['id'=>$tra->idrawat])->one();
		
			if ($trx->load(Yii::$app->request->post())){
			$trx->idtrx = $tra->idtrx;
			$trx->no_rm= $model->no_rekmed;
			$trx->idrawat= $model->id;
			$trx->tanggal= date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));;
			if($trx->save(false)){
				$trx->harga = $trx->tindakan->tarif;
				$trx->total = $trx->harga * $trx->jumlah;
				$trx->save();
			 
				return $this->render('edit', [
					'model' => $model,
					'trx' => $trx,
					'tra' => $tra,
				]);
			}
			else
			{	
				return $this->render('edit', [
					'model' => $model,
					'trx' => $trx,
					'tra' => $tra,
				]);

			}
			
		   
		}
        return $this->render('edit', [
            'model' => $model,
            'trx' => $trx,
            'tra' => $tra,
        ]);
    }
    public function actionView($id)
    {
		$trx = new Trandetail;
		$tra = new Transaksi;
		$model = $this->findModel($id);
			if ($trx->load(Yii::$app->request->post())){
			$tra->genKode();
			$trx->idtrx = $tra->idtrx;
			$trx->no_rm= $model->no_rekmed;
			$trx->idrawat= $model->id;
			$trx->tanggal= date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
			if($trx->save(false)){
			 $trx->harga = $trx->tindakan->tarif;
			 $trx->total = $trx->harga * $trx->jumlah;
				$trx->save();
				return $this->render('view', [
					'model' => $this->findModel($id),
					'trx' => $trx,
					'tra' => $tra,
				]);
			}
			else
			{	
				return $this->render('view', [
					'model' => $model,
					'trx' => $trx,
					'tra' => $tra,
				]);

			}
			
		   
		}
        return $this->render('view', [
            'model' => $this->findModel($id),
            'trx' => $trx,
            'tra' => $tra,
        ]);
    }
	 public function actionBeres()
    {
		return $this->redirect(['index']);
	}
	 public function actionDeletetind($id)
    {
        $tindakan = Trandetail::find()->where(['id'=>$id])->one();
		$tindakan->delete();
         return $this->redirect(Yii::$app->request->referrer);
		
    }
	
	public function actionUppulang($id){
		$model = $this->findModel($id);
		$trx = new Trandetail;
		$tra = new Transaksi;
		if($model->load(Yii::$app->request->post())){
			$tra->genKode();
			$trx->idtrx = $tra->idtrx;
			$trx->no_rm= $model->no_rekmed;
			$trx->idrawat= $model->id;
			$trx->tanggal= date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
			if($model->idjenisrawat == 2){
				if($model->idbayar == 4){
					$trx->harga = 110000;
					$trx->idtindakan = 52;
					$trx->jumlah = 1;
					$trx->total = $trx->harga;
				}else{
				$kelas = $model->idkelas;
				$tglmasuk = $model->tgldaftar;
				$tglkeluar = $model->tglkbayar;
				$lamarawat = strtotime($model->tglkbayar) - strtotime($model->tgldaftar);
				$lm = floor($lamarawat/86400)+2;
				if($model->idkelas == 1){
					$t1 = 20000 * $lm;
					$t2 = 3000 ;
					$t3 = 4000  ;
					$t4 = 10000 ;
					$tt = ($t2+$t3+$t4) * $lm;
					$te = $t1 + $tt;
					$trx->harga = $te;
					$trx->idtindakan = 52;
					$trx->jumlah = 1;
					$trx->total = $trx->harga;
				}else if($model->idkelas == 2){
					$t1 = 20000 * $lm;
					$t2 = 2500 ;
					$t3 = 4000  ;
					$t4 = 10000 ;
					$tt =($t2+$t3+$t4) * $lm;
					$te = $t1+ $tt;
					$trx->harga = $te;
					$trx->idtindakan = 52;
					$trx->jumlah = 1;
					$trx->total = $trx->harga;
				}else{
					$t1 = 20000 * $lm;
					$t2 = 2000 ;
					$t3 = 4000  ;
					$t4 = 10000 ;
					$tt = ($t2+$t3+$t4) * $lm;
					$te = $t1 + $tt;
					$trx->harga = $te;
					$trx->idtindakan = 52;
					$trx->jumlah = 1;
					$trx->total = $trx->harga;
				}
			}
			}else{
				$trx->idtindakan = 51 ;
				$trx->jumlah = 1 ;
			}
			if($model->save()){
				if($model->idjenisrawat != 2){

					if($trx->save()){
						if($model->idbayar == 5){
							$trx->harga = $trx->tindakan->tarifbpjs;
							$trx->total = $trx->harga;
							$trx->save();
						}else{
							$trx->harga = $trx->tindakan->tarif;
							$trx->total = $trx->harga;
							$trx->save();
						}
							return $this->redirect(['cassa/view/'.$model->id]);
						}	
					}
				else{
					$trx->save(false);
					return $this->redirect(['cassa/view/'.$model->id]);
				}
			}
				
		}
		 return $this->render('uppulang', [
            'model' => $this->findModel($id)
        ]);
	}
	
	 public function actionSelesai($id)
    {
		$tra = new Transaksi;
		$trx = new Transaksi;
		$model = $this->findModel($id);
		//$trx = Trandetail::find()->where(['idrawat'=>$model->id])->one();
		$tra->genKode();
		$tra->status = 1;
		$tra->no_rm = $model->no_rekmed;
		$tra->idrawat = $model->id;
		$tra->tglbayar = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));;
		$tra->idbayar = $model->idbayar;
		// if($model->idkelas == 1){
			// $pavilum
		// }
		if($tra->save(false)){
			$model->sbayar = $tra->status;
			$model->save(false);
			return $this->redirect(['index']);
		}
	}
		
        

    /**
     * Creates a new Rawatjalan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Rawatjalan();
		
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }
	public function actionKeybpjs(){
			$data = "29250";
			$secretKey = "5lQ5E30F4C";
         // Computes the timestamp
          date_default_timezone_set('UTC');
          $tStamp = strval(time()-strtotime('1970-01-01 00:00:00'));
           // Computes the signature by hashing the salt with the secret key as the key
			$signature = hash_hmac('sha256', $data."&".$tStamp, $secretKey, true);
 
   // base64 encode…
   $encodedSignature = base64_encode($signature);
	 return $this->render('keybpjs', [
            'secretKey' => $secretKey,
            'encodedSignature' => $encodedSignature,
            'signature' => $signature,
			'tStamp'=>$tStamp,
			
        ]);
   }

    /**
     * Updates an existing Rawatjalan model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */


	
    /**
     * Deletes an existing Rawatjalan model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
  

    /**
     * Finds the Rawatjalan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Rawatjalan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Rawatjalan::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
	protected function findTindakan($id)
    {
        if (($model = Transaksi::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }


	}
