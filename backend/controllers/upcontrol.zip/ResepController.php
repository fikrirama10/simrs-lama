<?php

namespace backend\controllers;

use Yii;
use kartik\mpdf\Pdf;
use common\models\Rawatjalan;
use common\models\Obat;
use common\models\RawatjalanSearch;
use common\models\PasienSearch;
use common\models\Resepdokter;
use common\models\Pasien;
use common\models\Trxmanual;
use common\models\Trxresep;
use common\models\Trxapotek;
use common\models\Rekamedis;
use common\models\Kartustok;
use common\models\RekamedisSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * RekamedisController implements the CRUD actions for Rekamedis model.
 */
class ResepController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Rekamedis models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RawatjalanSearch();
		$where = ['<>','idjenisrawat',2];
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams,$where);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	public function actionView($id){
		$model = $this->findRajal($id);
		
		return $this->render('view', [
            'model' => $model,
        ]);
	
	}
	
	public function actionCek($id){
		$rp = Trxresep::find()->where(['id'=>$id])->one();
		$st = Kartustok::find()->where(['idtrx'=>$resep->idtrx])->one();
		$ob = Obat::find()->where(['idobat'=>$resep->idobat])->one();
		
	}
	public function actionCreateresep($id){
		$model = $this->findTrx($id);
		$rawat = Rawatjalan::find()->where(['id'=>$model->idrawat])->one();
		$resep = new Trxresep();
		$stok = new Kartustok();
		if($resep->load(Yii::$app->request->post())){
			$resep->trxid = $model->idtrx;
			$resep->tanggal  = $model->tglresep;
			$resep->iduser  = Yii::$app->user->identity->id;
			$resep->norm  = $model->norm;			
			$resep->harga = $resep->obat->harga;
			$resep->satuan = $resep->obat->idsatuan;
			$resep->total = $resep->obat->harga * $resep->jumlah;	
			$obatt = Obat::find()->where(['id'=>$resep->idobat])->one();
			if($obatt->stok < $resep->jumlah){
				\Yii::$app->getSession()->setFlash('danger', 'Gagal ditambah Stok Obat Kurang');
				return $this->refresh();
			}else{
					$rsp = Trxresep::find()->where(['idobat'=>$resep->idobat])->andwhere(['trxid'=>$model->idtrx])->count();
					if($rsp > 0){
						$rspe = Trxresep::find()->where(['idobat'=>$resep->idobat])->andwhere(['trxid'=>$model->idtrx])->one();
						$stk = Kartustok::find()->where(['idtrx'=>$rspe->id])->one();
						$obt = Obat::find()->where(['id'=>$rspe->idobat])->one();
						$rspe->jumlah = $rspe->jumlah + $resep->jumlah ; 
						$rspe->total = $rspe->obat->harga * $rspe->jumlah ; 
						$stk->stokawal = $obt->stok;
						$stk->qty = $rspe->jumlah;
						$stk->stokakhir = $stk->stokawal - $stk->qty;
						$obt->stok = $stk->stokakhir;
						$rspe->save(false);
						$stk->save(false);
						$obt->save(false);
						return $this->refresh();
					}else{
						if($resep->save(false)){
						$obat = Obat::find()->where(['id'=>$resep->idobat])->one();
						$stok->trxid = $model->idtrx;
						$stok->idtrx = $resep->id;
						$stok->stokawal = $obat->stok;
						$stok->idobat = $obat->id;
						$stok->qty = $resep->jumlah;
						$stok->idtkp = $model->idlok;
						$stok->tgl = date('Y-m-d G:i:s',strtotime('+6 hour',strtotime(date('Y-m-d G:i:s'))));
						$stok->user = Yii::$app->user->identity->id;
						$stok->stokakhir = $stok->stokawal - $stok->qty;
						$obat->stok = $stok->stokakhir;
						$stok->save(false);
						$obat->save(false);
						return $this->refresh();
						}else{
							return $this->render('createresep', [
								'model' => $model,
								'rawat' => $rawat,
								'resep' => $resep,
							]);
						}
					}				
			
			}		
			
		}else{
			return $this->render('createresep', [
            'model' => $model,
            'rawat' => $rawat,
			'resep' => $resep,
        ]);
		}
		return $this->render('createresep', [
            'model' => $model,
            'rawat' => $rawat,
			'resep' => $resep,
        ]);
	
	}
	public function actionSelesai($id){
		$model= $this->findTrx($id);
		$resep= Trxresep::find()->where(['trxid'=>$model->idtrx])->all();
		$hargatotal = 0;
		foreach($resep as $rp){
			$hargatotal += $rp->total;
		}
		$model->total = $hargatotal;
		$model->status = 1;
		$model->save(false);
		return $this->redirect(['view', 'id' => $model->idrawat]);
		
	}
	public function actionHapusobat($id){
		$resep = Trxresep::find()->where(['id'=>$id])->one();
		$obat = Obat::find()->where(['id'=>$resep->idobat])->one();
		$stok = Kartustok::find()->where(['idtrx'=>$resep->id])->one();
		$obat->stok = $stok->stokawal;
		if($obat->save(false)){
			$stok->delete();
			$resep->delete();
			return $this->redirect(Yii::$app->request->referrer);
		}
	}
	public function actionDetail($id){
		$model = $this->findRajal($id);
		$trxman = new Trxapotek();
		$trxman->genNoresep();
		$trxman->koderawat= $model->idrawat;
		$trxman->idrawat= $model->id;
		$trxman->norm= $model->no_rekmed;
		$trxman->idlok= $model->idjenisrawat;
		$trxman->idbayar= $model->idbayar;
		$trxman->nama= $model->pasien->nama_pasien;
		$trxman->tgl= $model->tgldaftar;
		$trxman->tglresep= date('Y-m-d G:i:s',strtotime('+6 hour',strtotime(date('Y-m-d G:i:s'))));
		if($trxman->save(false)){
			 return $this->redirect(['resep/createresep/'.$trxman->id]);
		}
	
	}
	
		
	 public function actionLabel($id) {
	  //tampilkan bukti proses
	  $model = Rawatjalan::find()->where(['id' => $id])->one();
	 
	  $content = $this->renderPartial('etiket',['model' => $model]);
	  
	  // setup kartik\mpdf\Pdf component
	  $pdf = new Pdf([
	   'mode' => Pdf::MODE_CORE,
	   'destination' => Pdf::DEST_BROWSER,
	   'format' => [70,34],
	   'marginTop' => '0',
	   'orientation' => Pdf::ORIENT_PORTRAIT, 
	   'marginLeft' => '1',
	   'marginRight' => '1',
	   'marginBottom' => '0',
	   'content' => $content,  
	   'cssFile' => '@frontend/web/css/paper.css',
	   //'options' => ['title' => 'Bukti Permohonan Informasi'],
	   ]);
		 $response = Yii::$app->response;
			$response->format = \yii\web\Response::FORMAT_RAW;
			$headers = Yii::$app->response->headers;
			$headers->add('Content-Type', 'application/pdf');
	  
	  // return the pdf output as per the destination setting
	  return $pdf->render(); 
	 }
	public function actionDelete($id)
    {
        $this->findModel($id)->delete();

         return $this->redirect(Yii::$app->request->referrer);
    }
 

    
    protected function findModel($id)
    {
        if (($model = Resepdokter::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

	protected function findTrx($id)
    {
        if (($model = Trxapotek::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

	protected function findRajal($id)
    {
        if (($model = Rawatjalan::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }}
